from distutils.core import setup
setup(name='dStorage',
        version='1.0b',
        py_modules=['dStorage'],
        AUTHOR = u'Leonardo de Araujo Lima',
        EMAIL = 'feraleomg@gmail.com',
        LICENSE = 'GPL3',
        URL = 'https://pypi.python.org/project/dStorage/'
)
