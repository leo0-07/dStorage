from distutils.core import setup
setup(name='dStorage',
      version='1.0b',
      py_modules=['dStorage'],
)

