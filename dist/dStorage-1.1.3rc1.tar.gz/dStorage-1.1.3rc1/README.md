# dStorage.

![Logo](https://asl-sl.com.br/dstorage/img/dStorage.png)


## asl-sl (São Lourenço - MG, Brazil)

Academia do software livre.

São Lourenço, Minas Gerais - Brazil.


the goal of the dStorage meta class is study and implements some other classes.

The project structure need a special atention for learn in github usage.

the dStorage class give some funcions to create databases, and automaticaly
generate a gui and console interface for the data class and database.

Examples of usage are included in examples directory.

## first versions.

My first studies are turned to only build a simple environment.

This environment create SQLite database, and make one integration with this database and Tk **GUI** and __CLI__ simple iterfaces.

On the second moment I try made one CLI interface on same database controlled by base class structures.

> Now I need learn and write the package structure on the right way, following the rules to 
> devel python applications. at moment this software work, but I think with it is only an 
> outline.
> Older versions creates database file on user home directory, the recent versions have a property to make these paths.
> Also on the recent versions I try improve dialogs properties, now is possible change window color for input **GUI** dialog. Also you can change de color of output **GUI** dialog.

This goal, are satisfied.

The base class, is based in one multidimensional array data type.

That show a simple use of these data types.

The integration with __CLI__ and __GUI__ interface are builded by base class.

The base class provide, insert and select funcions.

Also are provide one simple find method.

One rule for base class use, is at moment, is needed one data member "id" on any derived class.

## Current.

The current version have insert, select, drop, data functions.

Also have some good options like optimization of file paths and colors for dialogs on **GUI.**

The library can be installed using python [**pip.**](https://pypi.org/project/dStorage/)

> python -m pip install --user dStorage

> the actual upstream release is on current [**git** repository](https://github.com/leo0-07/dStorage) branch.

[contact/contato:](mailto:feraleomg@gmail.com)

I have some time studying various tecnologic related sciences and aspects.

During a long time I teach use, administration and development with some UNIX Like operating systems.

Excuse some troubles in my codes, I try be better....

Grateful.
Special thanks to python comunity for the oportunity to colaborate.
Excuse for my troubles in package construction, I need more pratice and for me is hard to restart on the right way. Some lectures are not clearly for my compreension, and I only can say forgive me for my limitations.


[**Website for my courses and studies:**](http://www.asl-sl.com.br)
> Here I provide some studies, projects related to tecnology. I teach in my small city during some time and already have some good stories about students. Here I am one of the first to use "UNIX" Like __Oses__ and try expand and estimulate these culture.

> On my courses and studies **website** I use __portuguese,__ my natural language.


[**Website search engine projects:**](http://magicbyte.tec.br:8888/)


> Here I install one public seaech __engine__ for studies end learning purposes.

> The software used, also promotes one metasearch, and small crawler.

> You are welcome to known and colaborate.

