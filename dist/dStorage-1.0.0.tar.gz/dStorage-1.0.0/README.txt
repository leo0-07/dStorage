The dStorage metaclass studdies.

I have a pssion for tecnology and some other areas.

I learn with computers since very new, on the start o 80's.

My academic formtaion is turned at middle level (tecnician) on teching and 
industrial automation.

About computers i have learned with 8 bit processors and BASIC interpreter.

With UNIX's environments i start in 90's. and realy i have improve my skills.

Actualy i have pratice in code with some languages and manage some network environments.

This project, try improve the speed of small applications development.

Also it can be used to teach and learn in some propgramming aspects.

linux77@disroot.org
