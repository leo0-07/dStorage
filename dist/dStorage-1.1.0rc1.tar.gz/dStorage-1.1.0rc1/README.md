# dStorage.

![Logo](img/dStorage.png "data storage")


## asl-sl

Academia do software livre.

São Lourenço, Minas Gerais - Brazil.


the goal of the dStorage meta class is study and implements some other classes.

The project structure need an special atention for learn in github usage.

the dStorage class give some funcions to create databases, and automaticaly
generate an gui and console interface for the data class and database.

Examples of usage are included in examples directory.

## first versions.

My first studies are turned to only build an simple environment.

This environment create SQLite database, and make one integration with this database and Tk **GUI** and __CLI__ simple iterfaces.

On the second moment i try made one CLI interface on same database controlled by base class structures.

> Now i need learn and write the package structure on the right way, following the rules to 
> devel python applications. at moment this software work, but i think with it is only an 
> outline.
> Older versions creates database file on user home directory, the recent versions have a property to make these path.
> Also on the recent versions i try improve dialogs properties, is possible change window color for input **GUI** dialog.

This goal, are satisfied.

The base class, is based in one multidimensional array data type.

That show a simple use of these data types.

The integration with CLI and GUI interface are builded by base class.

The base class provide, insert and select funcions.

Also are provide one simple find method.

One rule for base class use, is at moment, is needed one data member "id" on any derived class.

## Current.

The current version have insert, select, drop, data functions.

[contact/contato:](mailto:feraleomg@gmail.com)

I have some time studying various tecnologic related sciences and aspects.

During a long time i teach use, administration and development with varios UNIX Like operating systems.

Excuse some troubles in my codes, i try be better....

Grateful.
Special thanks to python comunity for the oportunity to try colaborate.
Escuse for my troublrd in pakage construction, i need mor prative and for me is hard to start on the right way. Some lectures are not clearly for my compreension, and i only ca sey escuse for my limitations.


[**Website for my courses and studies:**](http://www.asl-sl.com.br)


[**Website search engine projects:**](http://magicbyte.tec.br:8888/)


