# asl-sl
the goal of the dStorage class is studdy and implements some other classes.
The project structure need an special atention for github use.
the dStorage class give some funcions to create databases, and automaticaly
generate an gui and console interface for the class database.
