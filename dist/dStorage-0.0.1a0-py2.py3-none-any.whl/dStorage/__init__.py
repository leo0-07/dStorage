''' these is the constructor of class '''
''' Está é a função construtora da classe'''
__version__ = "0.0.1a0"
